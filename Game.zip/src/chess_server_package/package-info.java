/**
 * Paczka chess_server_package zawiera klasy i metody do obsługi komunikacji: <p></p>
 * użytkownik - serwer: {@link chess_server_package.Client}, <p></p>
 * serwer - użytkownik: {@link chess_server_package.Server.ConnectionHandler}, <p></p>
 * serwer - baza danych: {@link chess_server_package.DataBaseConnection}.
 */
package chess_server_package;